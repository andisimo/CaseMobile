﻿//!
//! Copyright (C) Microsoft Corporation.  All rights reserved.
//!
(function(Core) {"use strict";
    Core.Namespace.define("AppMagic.Config.Worker", {
        contractsjs: "/js/AppMagic.Common.js", constantsjs: "/js/constants.js", debugjs: "/js/debug.js", dispatchWorkerjs: "/js/dispatchWorker.js"
    })
})(WinJS);